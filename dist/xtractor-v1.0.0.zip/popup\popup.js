// Xtractor Popup Controller - Pro Video Engine
// Fixes: Accurate title resolution, human-readable file sizes, non-laggy video output, single-file download.

// Global suppression of benign third-party library notices (e.g. MPEG-TS stream_type 0x15 ID3 metadata notes)
if (typeof console !== 'undefined' && console.warn) {
  const _origWarn = console.warn;
  console.warn = function(...args) {
    if (args[0] && typeof args[0] === 'string' && args[0].includes('stream_type 0x15')) {
      return;
    }
    return _origWarn.apply(console, args);
  };
}
if (typeof globalThis !== 'undefined' && globalThis.Mediabunny && globalThis.Mediabunny.Logging) {
  try {
    globalThis.Mediabunny.Logging.level = 1; // Errors only
  } catch (_) {}
}

document.addEventListener('DOMContentLoaded', async () => {
  let activeTabId = null;
  let allMedia = [];
  let currentFilter = 'all';
  let searchQuery = '';
  let previewMediaItem = null;
  let currentHlsInstance = null;
  let previewMediaRecorder = null;
  let previewRecordedChunks = [];

  // DOM Elements
  const mediaList = document.getElementById('mediaList');
  const emptyState = document.getElementById('emptyState');
  const searchInput = document.getElementById('searchInput');
  const footerInfo = document.getElementById('footerInfo');
  const toast = document.getElementById('toast');

  // Ensure mouse wheel scroll immediately scrolls cards container
  if (mediaList) {
    mediaList.addEventListener('wheel', (e) => {
      if (mediaList.scrollHeight > mediaList.clientHeight) {
        mediaList.scrollTop += e.deltaY;
      }
    }, { passive: true });
  }

  // Header Buttons
  const btnForceDownload = document.getElementById('btnForceDownload');
  const btnRescan = document.getElementById('btnRescan');
  const btnOptions = document.getElementById('btnOptions');
  const btnDownloadAll = document.getElementById('btnDownloadAll');
  const batchCount = document.getElementById('batchCount');
  const btnForceEmpty = document.getElementById('btnForceEmpty');
  const btnClearMedia = document.getElementById('btnClearMedia');

  // Preview elements
  const previewModal = document.getElementById('previewModal');
  const previewBackdrop = document.getElementById('previewBackdrop');
  const previewTitle = document.getElementById('previewTitle');
  const previewPlayer = document.getElementById('previewPlayer');
  const btnClosePreview = document.getElementById('btnClosePreview');
  const btnDownloadFromPreview = document.getElementById('btnDownloadFromPreview');

  // Badges
  const countAll = document.getElementById('countAll');
  const countVideo = document.getElementById('countVideo');
  const countAudio = document.getElementById('countAudio');

  let activeTabTitle = '';
  let isInternalPage = false;

  function sendTabMessageSafe(tabId, message, callback) {
    if (!tabId || tabId <= 0) {
      if (callback) callback(null);
      return;
    }
    try {
      chrome.tabs.sendMessage(tabId, message, (res) => {
        const _err = chrome.runtime.lastError;
        if (callback) callback(_err ? null : res);
      });
    } catch (_) {
      if (callback) callback(null);
    }
  }

  function sendRuntimeMessageSafe(message, callback) {
    try {
      chrome.runtime.sendMessage(message, (res) => {
        const _err = chrome.runtime.lastError;
        if (callback) callback(_err ? null : res);
      });
    } catch (_) {
      if (callback) callback(null);
    }
  }

  function showToast(message, duration = 2500) {
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, duration);
  }

  function sanitizeFilename(name) {
    if (!name) return 'video';
    let clean = name.trim();
    clean = clean.replace(/[<>:"/\\|?*\x00-\x1F\r\n\t]/g, '_').trim();
    clean = clean.replace(/_+/g, '_').replace(/\.+$/, '');
    return clean.slice(0, 100) || 'video';
  }

  function isGenericTitle(str) {
    if (!str) return true;
    const s = str.trim().toLowerCase();
    const genericWords = [
      'video', 'media', 'audio', 'player', 'video player', 'video_player',
      'interactive video', 'interactive video player', 'interactive content', 'interactive_video',
      'h5p', 'h5p interactive video', 'html5 video player', 'embedded video',
      'embed', 'home', 'untitled', 'document', 'index', 'master', 'playlist',
      'manifest', 'chunklist', 'stream', 'chunks', 'segment', 'output', 'variant',
      'apna college', 'apnacollege', 'sigma', 'sigma 6.0', 'sigma 5.0', 'sigma 4.0',
      'course', 'lecture', 'lesson', 'chapter', 'download', 'preview', 'playback',
      'watch video', 'watch'
    ];
    if (genericWords.includes(s)) return true;
    if (/^video[_-]?\d*$/i.test(s) || /^media[_-]?\d*$/i.test(s) || /^blob:/i.test(s)) return true;
    if (/^interactive[\s_-]*video/i.test(s)) return true;
    if (/^h5p[\s_-]*/i.test(s)) return true;
    if (/^(master|index|playlist|manifest|chunklist|stream|chunks|segment|output|variant)$/i.test(s)) return true;
    if (/^[0-9a-f_-]{6,}$/i.test(s) || /^\d+$/.test(s)) return true;
    if (s.includes('_mp4_h264_') || s.includes('_hls_') || s.includes('chunk_')) return true;
    return false;
  }

  function cleanPageTitle(raw) {
    if (!raw) return '';
    let t = raw.trim();
    // Strip site branding
    t = t.replace(/\s*[-|–—•:]\s*(YouTube|Vimeo|Dailymotion|Twitter|X|Facebook|TikTok|Twitch|Netflix|Hulu|Disney\+|Prime Video|Watch Online|Free Full|HD|1080p|720p|Official Video|Official Music Video|Video Player|Streaming|Movie|Full Movie|Apna College|ApnaCollege|Sigma 6\.0|Sigma 5\.0|Sigma 4\.0|Sigma|Coursera|Udemy|Physics Wallah|PW|Unacademy|GeeksforGeeks|GFG|Khan Academy|Classplus|Graphy|Teachable).*$/i, '');
    t = t.replace(/^(Watch|Playing|Video|Lecture|Lesson)\s*[-|–—•:]\s*/i, '');
    t = t.replace(/^Watch\s+/i, '');
    t = t.replace(/\s+Online\s*(Free)?$/i, '');
    // Strip extension suffixes
    t = t.replace(/\.(mp4|m3u8|webm|mov|mkv|flv|ts|avi)$/i, '');
    t = sanitizeFilename(t);
    if (!t || isGenericTitle(t)) return '';
    return t;
  }

  function formatBytes(bytes) {
    if (!bytes || bytes <= 50000) return 'Full Video (HD)'; // Never show "752 B" for video streams!
    const units = ['B', 'KB', 'MB', 'GB'];
    let i = 0;
    let val = bytes;
    while (val >= 1024 && i < units.length - 1) {
      val /= 1024;
      i++;
    }
    return `${val.toFixed(1)} ${units[i]}`;
  }

  function isHlsMedia(item) {
    if (!item) return false;
    if (item.isHls) return true;
    const url = (item.url || '').toLowerCase();
    const mime = (item.mimeType || '').toLowerCase();
    return url.includes('.m3u8') || mime.includes('mpegurl');
  }

  // Fast Base64 to ArrayBuffer decoder for IPC segment transfers
  function base64ToArrayBuffer(base64) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }

  // Unified robust segment fetcher with direct fetch + authenticated page proxy fallback
  async function fetchSegmentBuffer(segUri, tabId) {
    // 1. Direct fetch with credentials
    try {
      const resp = await fetch(segUri, { credentials: 'include' });
      if (resp.ok) {
        const buf = await resp.arrayBuffer();
        if (buf && buf.byteLength > 0) return buf;
      }
    } catch (e) {}

    // 2. Authenticated page proxy fetch fallback (bypasses CORS/hotlink protection)
    if (tabId) {
      try {
        const proxyRes = await new Promise(resolve => {
          sendTabMessageSafe(tabId, { type: 'PAGE_PROXY_FETCH_BLOB', url: segUri }, resolve);
        });
        if (proxyRes && proxyRes.success && proxyRes.base64) {
          return base64ToArrayBuffer(proxyRes.base64);
        } else if (proxyRes && proxyRes.data) {
          return new Uint8Array(proxyRes.data).buffer;
        }
      } catch (e) {}
    }

    return null;
  }

  /**
   * Transmux MPEG-TS chunks into a standard MP4 container.
   * Primary: Mediabunny — produces standard non-fragmented MP4 with single moov and full stss
   * (Sync Sample Box) keyframe index. Plays smoothly with 0 lag/stutter in all media players
   * (VLC, Windows Media Player, QuickTime, Chrome, TV/mobile) and seeks instantaneously.
   * Fallback: mux.js with monotonic sequence numbering.
   *
   * @param {ArrayBuffer[]} tsChunks - Array of MPEG-TS segment buffers
   * @param {Function} [onProgress] - Optional progress callback (0 to 1)
   * @returns {Blob} - MP4 blob ready for download
   */
  async function transmuxTsToMp4(tsChunks, onProgress) {
    if (!tsChunks || tsChunks.length === 0) {
      return new Blob([], { type: 'video/mp4' });
    }

    const combinedBlob = new Blob(tsChunks, { type: 'video/mp2t' });

    // 1. Primary High-Performance Muxer: Mediabunny
    const mb = window.Mediabunny || globalThis.Mediabunny;
    if (mb && mb.Input && mb.Output && mb.Conversion && mb.MpegTsInputFormat && mb.Mp4OutputFormat) {
      try {
        console.log('[Xtractor] Transmuxing TS to standard MP4 via Mediabunny...');
        const input = new mb.Input({
          formats: [new mb.MpegTsInputFormat()],
          source: new mb.BlobSource(combinedBlob),
        });

        const output = new mb.Output({
          format: new mb.Mp4OutputFormat(),
          target: new mb.BufferTarget(),
        });

        const conversion = await mb.Conversion.init({
          input,
          output,
        });

        if (conversion.isValid) {
          if (typeof onProgress === 'function') {
            conversion.onProgress = (prog) => {
              try { onProgress(prog); } catch (_) {}
            };
          }
          await conversion.execute();
          const mp4Buffer = output.target.buffer;
          if (mp4Buffer && mp4Buffer.byteLength > 0) {
            console.log(`[Xtractor] Mediabunny transmux complete: ${(mp4Buffer.byteLength / 1048576).toFixed(1)} MB`);
            return new Blob([mp4Buffer], { type: 'video/mp4' });
          }
        } else {
          console.warn('[Xtractor] Mediabunny conversion invalid, discarded:', conversion.discardedTracks);
        }
      } catch (mbErr) {
        console.warn('[Xtractor] Mediabunny error, falling back to secondary transmuxer:', mbErr);
      }
    }

    // 2. Secondary Fallback: mux.js
    if (!window.muxjs || !window.muxjs.mp4 || !window.muxjs.mp4.Transmuxer) {
      console.warn('mux.js not available, falling back to raw TS concatenation');
      return new Blob(tsChunks, { type: 'video/mp4' });
    }

    return new Promise((resolve) => {
      let resolved = false;
      const safeResolve = (blob) => {
        if (!resolved) {
          resolved = true;
          resolve(blob);
        }
      };

      try {
        const transmuxer = new window.muxjs.mp4.Transmuxer();

        let initSegment = null;
        const allDataParts = [];
        let globalSequenceNumber = 0;

        function reorderAndPatchBoxes(dataBytes) {
          let offset = 0;
          const boxes = [];
          while (offset <= dataBytes.length - 8) {
            const size = (dataBytes[offset] << 24) | (dataBytes[offset + 1] << 16) | (dataBytes[offset + 2] << 8) | dataBytes[offset + 3];
            if (size <= 0 || offset + size > dataBytes.length) break;
            boxes.push(dataBytes.subarray(offset, offset + size));
            offset += size;
          }

          const videoBoxes = [];
          const audioBoxes = [];
          let currentTarget = null;

          for (const box of boxes) {
            const type = String.fromCharCode(box[4], box[5], box[6], box[7]);
            if (type === 'moof') {
              let isVideo = true;
              for (let i = 0; i < box.length - 12; i++) {
                if (box[i] === 0x74 && box[i + 1] === 0x66 && box[i + 2] === 0x68 && box[i + 3] === 0x64) {
                  box[i + 5] |= 0x02; // default-base-is-moof flag
                  const trackId = (box[i + 8] << 24) | (box[i + 9] << 16) | (box[i + 10] << 8) | box[i + 11];
                  if (trackId === 257) isVideo = false;
                  break;
                }
              }
              currentTarget = isVideo ? videoBoxes : audioBoxes;
              currentTarget.push(box);
            } else if (type === 'mdat') {
              if (currentTarget) currentTarget.push(box);
            } else {
              videoBoxes.push(box);
            }
          }

          const orderedBoxes = [...videoBoxes, ...audioBoxes];

          for (const box of orderedBoxes) {
            const type = String.fromCharCode(box[4], box[5], box[6], box[7]);
            if (type === 'moof' && box.length >= 24) {
              if (box[12] === 0x6d && box[13] === 0x66 && box[14] === 0x68 && box[15] === 0x64) {
                const seq = globalSequenceNumber++;
                box[20] = (seq >>> 24) & 0xff;
                box[21] = (seq >>> 16) & 0xff;
                box[22] = (seq >>> 8) & 0xff;
                box[23] = seq & 0xff;
              }
            }
          }

          return orderedBoxes;
        }

        transmuxer.on('data', (segment) => {
          if (segment.initSegment && segment.initSegment.byteLength > 0 && !initSegment) {
            initSegment = new Uint8Array(segment.initSegment);
          }
          if (segment.data && segment.data.byteLength > 0) {
            const reordered = reorderAndPatchBoxes(new Uint8Array(segment.data));
            allDataParts.push(...reordered);
          }
        });

        transmuxer.on('error', (err) => {
          console.error('Transmux error:', err);
          safeResolve(new Blob(tsChunks, { type: 'video/mp4' }));
        });

        for (const chunk of tsChunks) {
          transmuxer.push(new Uint8Array(chunk));
          transmuxer.flush();
        }

        if (!initSegment || allDataParts.length === 0) {
          console.warn('Transmux produced no output, falling back to raw TS');
          safeResolve(new Blob(tsChunks, { type: 'video/mp4' }));
          return;
        }

        const parts = [initSegment, ...allDataParts];
        const blob = new Blob(parts, { type: 'video/mp4' });
        console.log(`Transmux complete: ${allDataParts.length} fragments, ${(blob.size / 1048576).toFixed(1)} MB`);
        safeResolve(blob);
      } catch (err) {
        console.error('Transmux exception:', err);
        safeResolve(new Blob(tsChunks, { type: 'video/mp4' }));
      }
    });
  }

  // Get active tab
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tabs && tabs[0]) {
    activeTabId = tabs[0].id;
    isInternalPage = !tabs[0].url || /^(chrome|edge|about|devtools|chrome-extension):/i.test(tabs[0].url);
    if (tabs[0].title) {
      activeTabTitle = cleanPageTitle(tabs[0].title);
    }
  }

  function applyResolvedTitle(resolvedTitle) {
    if (!resolvedTitle || isGenericTitle(resolvedTitle)) return;
    allMedia.forEach(m => {
      if ((!m.tabId || m.tabId === activeTabId) && (!m.title || isGenericTitle(m.title) || m.title.toLowerCase().includes('interactive video'))) {
        m.title = resolvedTitle;
      }
    });
  }

  function deduplicateMediaList(items) {
    if (!items || items.length <= 1) return items || [];
    const hasHlsStream = items.some(m => isHlsMedia(m));
    let list = items;
    if (hasHlsStream) {
      list = list.filter(m => !m.isBlobPlayer && !(m.url && m.url.startsWith('blob:')));
    }
    const masterItem = list.find(m => isHlsMedia(m) && (m.url?.includes('master') || m.url?.includes('manifest')));
    if (masterItem && masterItem.url) {
      const masterBase = masterItem.url.split('?')[0].replace(/master[^/]*\.m3u8$/i, '');
      list = list.filter(m => {
        if (m === masterItem) return true;
        if (isHlsMedia(m) && masterBase && m.url && m.url.startsWith(masterBase)) return false;
        return true;
      });
    }
    const seen = new Set();
    const result = [];
    for (const item of list) {
      const cleanUrl = item.cleanUrl || (item.url ? item.url.split('?')[0] : '');
      const key = `${item.title || ''}_${item.category || ''}_${isHlsMedia(item) ? 'hls' : cleanUrl}`;
      if (!seen.has(key)) {
        seen.add(key);
        result.push(item);
      }
    }
    return result.length > 0 ? result : items;
  }

  // Load Media and Resolve Exact Video Title
  function loadMedia() {
    sendRuntimeMessageSafe({ type: 'GET_TAB_MEDIA', tabId: activeTabId }, (response) => {
      allMedia = deduplicateMediaList((response && response.media) ? response.media : []);

      if (activeTabTitle && !isGenericTitle(activeTabTitle)) {
        applyResolvedTitle(activeTabTitle);
      }

      // Query TOP frame specifically for og:title / h1 / page title on accessible web pages
      if (!isInternalPage && activeTabId) {
        sendTabMessageSafe(activeTabId, { type: 'GET_PAGE_TITLE' }, (titleRes) => {
          if (titleRes && titleRes.title) {
            const docTitle = cleanPageTitle(titleRes.title);
            if (docTitle && !isGenericTitle(docTitle)) {
              activeTabTitle = docTitle;
              applyResolvedTitle(docTitle);
            }
          }
          updateCounts();
          renderMedia();
        });
        return;
      }

      updateCounts();
      renderMedia();
    });
  }

  function updateCounts() {
    const total = allMedia.length;
    const videos = allMedia.filter(m => m.category === 'video').length;
    const audios = allMedia.filter(m => m.category === 'audio').length;

    countAll.textContent = total;
    countVideo.textContent = videos;
    countAudio.textContent = audios;

    footerInfo.textContent = `${total} video${total === 1 ? '' : 's'} (FIFO: max 10)`;

    // Keep extension badge in immediate 100% sync with popup cards
    if (chrome.action && chrome.action.setBadgeText) {
      chrome.action.setBadgeText({ text: total > 0 ? (total > 99 ? '99+' : String(total)) : '' });
      chrome.action.setBadgeBackgroundColor({ color: '#4F46E5' });
    }
  }

  // Render cards
  function renderMedia() {
    mediaList.innerHTML = '';

    const filtered = allMedia.filter(item => {
      if (currentFilter !== 'all' && item.category !== currentFilter) {
        return false;
      }
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = item.title && item.title.toLowerCase().includes(q);
        const matchesFormat = item.format && item.format.toLowerCase().includes(q);
        if (!matchesTitle && !matchesFormat) return false;
      }
      return true;
    });

    if (filtered.length >= 2) {
      btnDownloadAll.style.display = 'block';
      batchCount.textContent = filtered.length;
    } else {
      btnDownloadAll.style.display = 'none';
    }

    if (filtered.length === 0) {
      emptyState.classList.add('active');
      mediaList.style.display = 'none';
      return;
    }

    emptyState.classList.remove('active');
    mediaList.style.display = 'block';

    filtered.forEach(item => {
      const card = createMediaCard(item);
      mediaList.appendChild(card);
    });
  }

  // Create Video Card with Title Display & Editing
  function createMediaCard(item) {
    const card = document.createElement('div');
    card.className = 'media-card';

    const isAudio = item.category === 'audio';
    const isBlob = item.isBlobPlayer || item.format === 'BLOB';

    let iconSvg = `
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
        <polygon points="23 7 16 12 23 17 23 7"/>
        <rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
      </svg>
    `;
    if (isAudio) {
      iconSvg = `
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M9 18V5l12-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0zm12 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
        </svg>
      `;
    }

    const isStream = isHlsMedia(item);
    const titleText = (item.title && !isGenericTitle(item.title) && !item.title.toLowerCase().includes('interactive video')) 
      ? item.title 
      : (activeTabTitle && !isGenericTitle(activeTabTitle) ? activeTabTitle : 'Video');
    item.title = titleText;
    const formatName = isAudio ? 'AUDIO MP3' : (item.resolution ? `${item.resolution} MP4` : 'MP4 VIDEO');
    const sizeDisplay = (!isStream && item.size && item.size > 50000) 
      ? formatBytes(item.size) 
      : (item.resolution ? `${item.resolution} HD` : 'Full Video (HD)');
    const resBadge = item.resolution ? `<span class="meta-badge badge-res">${item.resolution}</span>` : '';

    card.innerHTML = `
      <div class="card-top">
        <div class="card-icon ${isAudio ? 'audio' : ''}">
          ${iconSvg}
        </div>
        <div class="card-details">
          <div class="card-title-row">
            <input type="text" class="card-title-input" value="${escapeHtml(titleText)}" placeholder="Video Title" title="Click to rename before download">
          </div>
          <div class="card-meta">
            <span class="meta-badge badge-format">${formatName}</span>
            ${resBadge}
            <span class="card-size">${sizeDisplay}</span>
          </div>
        </div>
      </div>
      <div class="card-actions">
        <button class="btn-download" data-id="${item.id}" title="Click to Download">
          <span class="btn-progress-bar"></span>
          <svg class="icon-dl" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.5">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
          </svg>
          <svg class="icon-pause" viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display: none;">
            <rect x="6" y="4" width="4" height="16" rx="1"/>
            <rect x="14" y="4" width="4" height="16" rx="1"/>
          </svg>
          <svg class="icon-resume" viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display: none;">
            <polygon points="6 4 20 12 6 20 6 4"/>
          </svg>
          <span class="btn-label">${isBlob ? 'Capture Video' : 'Download Video'}</span>
        </button>
        <button class="btn-secondary btn-preview" data-id="${item.id}">
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <polygon points="10 8 16 12 10 16 10 8"/>
          </svg>
          Preview
        </button>
        <button class="btn-secondary btn-copy" data-url="${escapeHtml(item.url)}" title="Copy stream URL">
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
          </svg>
          Copy
        </button>
        <button class="btn-secondary btn-remove" data-id="${item.id}" title="Remove from queue">
          <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
      <div class="card-progress-track">
        <div class="card-progress-fill"></div>
      </div>
    `;

    const titleInput = card.querySelector('.card-title-input');
    titleInput.addEventListener('input', () => {
      item.title = titleInput.value.trim() || activeTabTitle || 'Video';
    });

    const dlBtn = card.querySelector('.btn-download');

    dlBtn.addEventListener('click', () => {
      // If this item is currently downloading or paused, clicking the bar toggles Pause / Resume!
      const activeCtrl = activeDownloads.get(item.id);
      if (activeCtrl) {
        togglePauseDownload(item.id);
        return;
      }

      const currentTitle = titleInput.value.trim() || item.title || activeTabTitle || 'Video';
      item.title = currentTitle;

      if (isBlob) {
        captureLivePlayer(item, dlBtn);
      } else if (isHlsMedia(item)) {
        downloadHlsVideoInPopup(item, dlBtn);
      } else {
        downloadDirectVideo(item, dlBtn);
      }
    });

    // Restore active downloading / paused UI if card re-renders
    const existingCtrl = activeDownloads.get(item.id);
    if (existingCtrl) {
      existingCtrl.btnElement = dlBtn;
      if (existingCtrl.isPaused) {
        updateDownloadProgress(dlBtn, existingCtrl.currentPercent, `⏸ Paused (${existingCtrl.currentPercent}%)`, 'paused');
      } else {
        updateDownloadProgress(dlBtn, existingCtrl.currentPercent, existingCtrl.lastStatusText, 'downloading');
      }
    }

    const prevBtn = card.querySelector('.btn-preview');
    prevBtn.addEventListener('click', () => {
      item.title = titleInput.value.trim() || item.title || 'Video';
      openPreview(item);
    });

    const copyBtn = card.querySelector('.btn-copy');
    copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(item.url).then(() => {
        showToast('Video link copied to clipboard!');
      }).catch(() => {
        showToast('Failed to copy link');
      });
    });

    const removeBtn = card.querySelector('.btn-remove');
    if (removeBtn) {
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        allMedia = allMedia.filter(m => m.id !== item.id);
        sendRuntimeMessageSafe({ type: 'REMOVE_MEDIA_ITEM', id: item.id }, () => {
          updateCounts();
          renderMedia();
          showToast('Video removed from queue');
        });
      });
    }

    return card;
  }

  // -------------------------------------------------------------
  // 1. IN-POPUP PREVIEW (Plays HLS Smoothly with Hls.js)
  // -------------------------------------------------------------
  function openPreview(item) {
    previewMediaItem = item;
    previewTitle.textContent = item.title || 'Video Preview';

    if (currentHlsInstance) {
      currentHlsInstance.destroy();
      currentHlsInstance = null;
    }

    if (item.isHls || item.url.includes('.m3u8')) {
      if (window.Hls && Hls.isSupported()) {
        currentHlsInstance = new Hls({
          enableWorker: true,
          lowLatencyMode: true
        });
        currentHlsInstance.loadSource(item.url);
        currentHlsInstance.attachMedia(previewPlayer);
        currentHlsInstance.on(Hls.Events.MANIFEST_PARSED, () => {
          previewPlayer.play().catch(() => {});
        });
      } else {
        previewPlayer.src = item.url;
        previewPlayer.play().catch(() => {});
      }
    } else {
      previewPlayer.src = item.url;
      previewPlayer.play().catch(() => {});
    }

    previewModal.classList.add('active');
  }

  function closePreview() {
    previewPlayer.pause();
    if (currentHlsInstance) {
      currentHlsInstance.destroy();
      currentHlsInstance = null;
    }
    previewPlayer.removeAttribute('src');
    previewPlayer.load();
    previewModal.classList.remove('active');
    previewMediaItem = null;
  }

  btnClosePreview.addEventListener('click', closePreview);
  previewBackdrop.addEventListener('click', closePreview);

  // Download directly from Preview modal
  btnDownloadFromPreview.addEventListener('click', () => {
    if (previewMediaItem) {
      const cleanTitle = sanitizeFilename(previewMediaItem.title || 'Video');
      showToast(`Saving: ${cleanTitle}.mp4`);
      
      const cardBtn = document.querySelector(`.btn-download[data-id="${previewMediaItem.id}"]`);
      // If preview is playing smoothly, capture stream directly for zero lag!
      if (isHlsMedia(previewMediaItem)) {
        downloadHlsVideoInPopup(previewMediaItem, cardBtn || btnDownloadFromPreview);
      } else if (previewMediaItem.url && previewMediaItem.url.startsWith('blob:')) {
        capturePreviewPlayerStream(cleanTitle);
      } else {
        downloadDirectVideo(previewMediaItem, cardBtn || btnDownloadFromPreview);
      }
      closePreview();
    }
  });

  // Direct Stream Download from Preview modal (preserves 100% untouched raw video + audio stream)
  const btnSaveDirectStream = document.getElementById('btnSaveDirectStream');
  if (btnSaveDirectStream) {
    btnSaveDirectStream.addEventListener('click', () => {
      if (previewMediaItem) {
        downloadDirectHlsStream(previewMediaItem);
        closePreview();
      }
    });
  }

  // Record directly from Preview modal with hardware audio-video synchronization
  const btnRecordFromPreview = document.getElementById('btnRecordFromPreview');
  if (btnRecordFromPreview) {
    btnRecordFromPreview.addEventListener('click', () => {
      if (previewMediaItem) {
        const cleanTitle = sanitizeFilename(previewMediaItem.title || activeTabTitle || 'Video');
        capturePreviewPlayerStream(cleanTitle);
      }
    });
  }

  // Capture from Preview player (Guarantees 100% Hardware-Synced Audio & Video!)
  function capturePreviewPlayerStream(title) {
    if (previewMediaRecorder && previewMediaRecorder.state === 'recording') {
      previewMediaRecorder.stop();
      return;
    }

    try {
      const stream = previewPlayer.captureStream ? previewPlayer.captureStream() : previewPlayer.mozCaptureStream();
      if (!stream) {
        downloadHlsVideoInPopup(previewMediaItem);
        return;
      }

      previewRecordedChunks = [];
      const mime = MediaRecorder.isTypeSupported('video/mp4') 
        ? 'video/mp4' 
        : (MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus') ? 'video/webm;codecs=vp9,opus' : 'video/webm');
      
      previewMediaRecorder = new MediaRecorder(stream, { mimeType: mime });

      if (btnRecordFromPreview) {
        btnRecordFromPreview.textContent = '⏹ Stop & Save Video';
        btnRecordFromPreview.classList.add('recording');
      }

      previewMediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) previewRecordedChunks.push(e.data);
      };

      previewMediaRecorder.onstop = () => {
        const blob = new Blob(previewRecordedChunks, { type: mime });
        const objectUrl = URL.createObjectURL(blob);
        saveSingleFile(objectUrl, `${title}.mp4`);
        showToast(`✓ Saved: ${title}.mp4`);
        if (btnRecordFromPreview) {
          btnRecordFromPreview.textContent = '🔴 Record Stream (Synced Audio)';
          btnRecordFromPreview.classList.remove('recording');
        }
        previewMediaRecorder = null;
      };

      previewMediaRecorder.start(1000);
      showToast('Recording video with 100% synchronized audio...');

      previewPlayer.onended = () => {
        if (previewMediaRecorder && previewMediaRecorder.state === 'recording') {
          previewMediaRecorder.stop();
        }
      };
    } catch (e) {
      console.error('Player capture error:', e);
      downloadHlsVideoInPopup(previewMediaItem);
    }
  }

  // Direct Stream Downloader (untouched original stream, preserving 100% video & audio tracks)
  async function downloadDirectHlsStream(item) {
    const btnElement = (item && item.id) ? document.querySelector(`.btn-download[data-id="${item.id}"]`) : null;
    const previewBtn = document.getElementById('btnSaveDirectStream');
    const ctrlId = item.id || item.url;

    if (activeDownloads.has(ctrlId)) {
      togglePauseDownload(ctrlId);
      return;
    }

    const ctrl = {
      id: ctrlId,
      isPaused: false,
      isCancelled: false,
      currentPercent: 0,
      btnElement,
      previewBtn,
      pause() {
        this.isPaused = true;
        updateDownloadProgress(this.btnElement, this.currentPercent, `⏸ Paused (${this.currentPercent}%)`, 'paused');
        updateDownloadProgress(this.previewBtn, this.currentPercent, `⏸ Paused (${this.currentPercent}%)`, 'paused');
        showToast('Download paused');
      },
      resume() {
        this.isPaused = false;
        updateDownloadProgress(this.btnElement, this.currentPercent, `Downloading ${this.currentPercent}%`, 'downloading');
        updateDownloadProgress(this.previewBtn, this.currentPercent, `Downloading ${this.currentPercent}%`, 'downloading');
        showToast('Resuming download...');
      }
    };

    activeDownloads.set(ctrlId, ctrl);

    updateDownloadProgress(btnElement, 0, 'Preparing...', 'downloading');
    updateDownloadProgress(previewBtn, 0, 'Preparing...', 'downloading');

    const cleanTitle = sanitizeFilename(item.title || activeTabTitle || 'Video');
    showToast(`Downloading direct stream: ${cleanTitle}...`);

    try {
      let text = '';
      try {
        const resp = await fetch(item.url);
        if (resp.ok) text = await resp.text();
      } catch (e) {}

      if (!text && activeTabId && !isInternalPage) {
        const pageFetch = await new Promise(resolve => {
          sendTabMessageSafe(activeTabId, { type: 'PAGE_PROXY_FETCH', url: item.url }, resolve);
        });
        if (pageFetch && pageFetch.success) text = pageFetch.text;
      }

      let targetMediaUrl = item.url;
      let mediaInfo = null;

      if (window.HlsParser && HlsParser.isMasterPlaylist(text)) {
        const variants = HlsParser.parseMaster(text, item.url);
        if (variants.length > 0) {
          targetMediaUrl = variants[0].uri;
          let varText = '';
          try {
            const varResp = await fetch(targetMediaUrl);
            if (varResp.ok) varText = await varResp.text();
          } catch (e) {}
          if (!varText && activeTabId && !isInternalPage) {
            const varFetch = await new Promise(resolve => {
              sendTabMessageSafe(activeTabId, { type: 'PAGE_PROXY_FETCH', url: targetMediaUrl }, resolve);
            });
            if (varFetch && varFetch.success) varText = varFetch.text;
          }
          if (varText) mediaInfo = HlsParser.parseMedia(varText, targetMediaUrl);
        }
        if (!mediaInfo || mediaInfo.segments.length === 0) {
          mediaInfo = HlsParser.parseMedia(text, targetMediaUrl);
        }
      } else if (window.HlsParser) {
        mediaInfo = HlsParser.parseMedia(text, targetMediaUrl);
      }

      if (!mediaInfo || mediaInfo.segments.length === 0) {
        console.warn('Could not parse HLS segments, attempting direct download...');
        downloadDirectVideo(item, btnElement);
        return;
      }

      const segments = mediaInfo.segments;
      const totalCount = segments.length;
      const chunkBuffers = new Array(totalCount).fill(null);
      let nextIndex = 0;
      let completed = 0;

      async function worker() {
        while (nextIndex < totalCount && !ctrl.isCancelled) {
          while (ctrl.isPaused && !ctrl.isCancelled) {
            await new Promise(r => setTimeout(r, 200));
          }
          if (ctrl.isCancelled || nextIndex >= totalCount) break;

          const idx = nextIndex++;
          const seg = segments[idx];
          let buf = null;
          let attempts = 0;
          while (attempts < 4 && !buf && !ctrl.isCancelled) {
            while (ctrl.isPaused && !ctrl.isCancelled) {
              await new Promise(r => setTimeout(r, 200));
            }
            if (ctrl.isCancelled) break;

            attempts++;
            try {
              buf = await fetchSegmentBuffer(seg.uri, activeTabId);
              if (buf && buf.byteLength > 0) {
                chunkBuffers[idx] = buf;
                completed++;
                const pct = Math.round((completed / totalCount) * 100);
                ctrl.currentPercent = pct;
                if (!ctrl.isPaused) {
                  updateDownloadProgress(btnElement, pct, `Downloading ${pct}%`, 'downloading');
                  updateDownloadProgress(previewBtn, pct, `Downloading ${pct}%`, 'downloading');
                }
                break;
              }
            } catch (e) {}
            if (!buf && attempts < 4 && !ctrl.isCancelled) await new Promise(r => setTimeout(r, 200 * attempts));
          }
        }
      }

      const workers = [];
      const concurrency = Math.min(4, totalCount);
      for (let i = 0; i < concurrency; i++) workers.push(worker());
      await Promise.all(workers);

      // Rescue pass for any missing chunks
      for (let i = 0; i < totalCount; i++) {
        while (ctrl.isPaused && !ctrl.isCancelled) {
          await new Promise(r => setTimeout(r, 200));
        }
        if (ctrl.isCancelled) break;

        if (!chunkBuffers[i]) {
          try {
            const rescueBuf = await fetchSegmentBuffer(segments[i].uri, activeTabId);
            if (rescueBuf && rescueBuf.byteLength > 0) chunkBuffers[i] = rescueBuf;
          } catch (e) {}
        }
      }

      const validChunks = chunkBuffers.filter(Boolean);
      if (validChunks.length === 0) {
        throw new Error('Could not download stream segments');
      }

      // Transmux MPEG-TS to proper MP4 for fast seeking; fMP4 streams pass through as-is
      let directBlob;
      if (mediaInfo && !mediaInfo.isFmp4) {
        updateDownloadProgress(btnElement, 0, 'Optimizing MP4...', 'optimizing');
        updateDownloadProgress(previewBtn, 0, 'Optimizing MP4...', 'optimizing');
        directBlob = await transmuxTsToMp4(validChunks, (prog) => {
          const optPct = Math.round(prog * 100);
          updateDownloadProgress(btnElement, optPct, `Optimizing: ${optPct}%`, 'optimizing');
          updateDownloadProgress(previewBtn, optPct, `Optimizing: ${optPct}%`, 'optimizing');
        });
      } else {
        directBlob = new Blob(validChunks, { type: 'video/mp4' });
      }

      const finalFilename = `${cleanTitle}.mp4`;
      const objectUrl = URL.createObjectURL(directBlob);
      saveSingleFile(objectUrl, finalFilename);
      showToast(`✓ Saved direct stream: ${finalFilename}`);
      updateDownloadProgress(btnElement, 100, '✓ Saved!', 'completed');
      updateDownloadProgress(previewBtn, 100, '✓ Saved!', 'completed');
    } catch (err) {
      console.error(err);
      showToast('Download error: ' + err.message);
      updateDownloadProgress(btnElement, 0, 'Download Video', 'reset');
      updateDownloadProgress(previewBtn, 0, 'Direct Stream', 'reset');
    } finally {
      activeDownloads.delete(ctrlId);
    }
  }

  // -------------------------------------------------------------
  // Active Downloads Controller (Pause / Resume Support)
  // -------------------------------------------------------------
  const activeDownloads = new Map(); // id -> controller

  function togglePauseDownload(id) {
    const ctrl = activeDownloads.get(id);
    if (!ctrl) return;
    if (ctrl.isPaused) {
      ctrl.resume();
    } else {
      ctrl.pause();
    }
  }

  // -------------------------------------------------------------
  // Dynamic Background Progress Bar Helper
  // Fills the background of the downloading bar from 0% to 100%
  // -------------------------------------------------------------
  function updateDownloadProgress(btnElement, percent, statusText, state = 'downloading') {
    if (!btnElement) return;
    const bar = btnElement.querySelector('.btn-progress-bar');
    const label = btnElement.querySelector('.btn-label') || btnElement;
    const card = btnElement.closest ? btnElement.closest('.media-card') : null;
    const cardBar = card ? card.querySelector('.card-progress-fill') : null;
    const clampedPct = Math.min(100, Math.max(0, percent));

    if (state === 'downloading') {
      btnElement.classList.add('downloading');
      btnElement.classList.remove('paused', 'optimizing', 'completed');
      btnElement.setAttribute('title', 'Click to Pause download');
      if (card) {
        card.classList.add('downloading');
        card.classList.remove('paused', 'optimizing');
      }
      if (bar) bar.style.width = `${clampedPct}%`;
      if (cardBar) cardBar.style.width = `${clampedPct}%`;
      if (label && statusText) label.textContent = statusText;
    } else if (state === 'paused') {
      btnElement.classList.add('downloading', 'paused');
      btnElement.classList.remove('optimizing', 'completed');
      btnElement.setAttribute('title', 'Click to Resume download');
      if (card) {
        card.classList.add('downloading', 'paused');
        card.classList.remove('optimizing');
      }
      if (bar) bar.style.width = `${clampedPct}%`;
      if (cardBar) cardBar.style.width = `${clampedPct}%`;
      if (label && statusText) label.textContent = statusText;
    } else if (state === 'optimizing') {
      btnElement.classList.add('downloading', 'optimizing');
      btnElement.classList.remove('paused', 'completed');
      btnElement.setAttribute('title', 'Finalizing seek index...');
      if (card) {
        card.classList.add('downloading', 'optimizing');
        card.classList.remove('paused');
      }
      if (bar) bar.style.width = `${clampedPct}%`;
      if (cardBar) cardBar.style.width = `${clampedPct}%`;
      if (label && statusText) label.textContent = statusText;
    } else if (state === 'completed') {
      btnElement.classList.remove('downloading', 'paused', 'optimizing');
      btnElement.classList.add('completed');
      btnElement.setAttribute('title', 'Download complete');
      if (card) { card.classList.remove('downloading', 'paused', 'optimizing'); }
      if (bar) bar.style.width = '100%';
      if (cardBar) cardBar.style.width = '100%';
      if (label) label.textContent = statusText || '✓ Saved!';
    } else if (state === 'reset') {
      btnElement.classList.remove('downloading', 'paused', 'optimizing', 'completed');
      btnElement.setAttribute('title', 'Click to Download');
      if (card) { card.classList.remove('downloading', 'paused', 'optimizing'); }
      if (bar) bar.style.width = '0%';
      if (cardBar) cardBar.style.width = '0%';
      if (label) label.textContent = statusText || 'Download Video';
    }
  }

  // -------------------------------------------------------------
  // 2. IN-POPUP HLS TO VIDEO DOWNLOADER
  // Downloads segments, handles CORS proxying, saves with EXACT title
  // -------------------------------------------------------------
  async function downloadHlsVideoInPopup(item, btnElement) {
    if (!btnElement && item && item.id) {
      btnElement = document.querySelector(`.btn-download[data-id="${item.id}"]`);
    }

    const ctrlId = item.id || item.url;

    if (activeDownloads.has(ctrlId)) {
      togglePauseDownload(ctrlId);
      return;
    }

    const ctrl = {
      id: ctrlId,
      isPaused: false,
      isCancelled: false,
      currentPercent: 0,
      lastStatusText: 'Downloading 0%',
      btnElement,
      pause() {
        this.isPaused = true;
        updateDownloadProgress(this.btnElement, this.currentPercent, `⏸ Paused (${this.currentPercent}%)`, 'paused');
        showToast('Download paused');
      },
      resume() {
        this.isPaused = false;
        updateDownloadProgress(this.btnElement, this.currentPercent, this.lastStatusText, 'downloading');
        showToast('Resuming download...');
      }
    };

    activeDownloads.set(ctrlId, ctrl);
    updateDownloadProgress(btnElement, 0, 'Preparing...', 'downloading');

    const cleanTitle = sanitizeFilename(item.title || activeTabTitle || 'Video');
    showToast(`Downloading: ${cleanTitle}...`);

    try {
      let text = '';
      // 1. Try direct fetch first
      try {
        const resp = await fetch(item.url);
        if (resp.ok) text = await resp.text();
      } catch (e) {}

      // 2. If direct fetch was blocked by CORS, fetch via active tab's authenticated context!
      if (!text && activeTabId && !isInternalPage) {
        const pageFetch = await new Promise(resolve => {
          sendTabMessageSafe(activeTabId, { type: 'PAGE_PROXY_FETCH', url: item.url }, resolve);
        });
        if (pageFetch && pageFetch.success) {
          text = pageFetch.text;
        }
      }

      if (!text) {
        throw new Error('Unable to access video stream. Try Preview -> Record.');
      }

      let targetMediaUrl = item.url;
      let mediaInfo = null;
      let separateAudioUri = null;

      if (window.HlsParser && HlsParser.isMasterPlaylist(text)) {
        const variants = HlsParser.parseMaster(text, item.url);
        if (variants.length > 0) {
          targetMediaUrl = variants[0].uri;
          if (variants[0].audioUri) {
            separateAudioUri = variants[0].audioUri;
          }
          // Fetch variant playlist
          let varText = '';
          try {
            const varResp = await fetch(targetMediaUrl);
            if (varResp.ok) varText = await varResp.text();
          } catch (e) {}

          if (!varText && activeTabId && !isInternalPage) {
            const varFetch = await new Promise(resolve => {
              sendTabMessageSafe(activeTabId, { type: 'PAGE_PROXY_FETCH', url: targetMediaUrl }, resolve);
            });
            if (varFetch && varFetch.success) varText = varFetch.text;
          }

          if (varText) {
            mediaInfo = HlsParser.parseMedia(varText, targetMediaUrl);
          }
        }
        // Fallback: If master playlist had no valid variants, or fetching variant failed, try parsing text as media playlist directly!
        if (!mediaInfo || mediaInfo.segments.length === 0) {
          mediaInfo = HlsParser.parseMedia(text, targetMediaUrl);
        }
      } else if (window.HlsParser) {
        mediaInfo = HlsParser.parseMedia(text, targetMediaUrl);
      }

      if (!mediaInfo || mediaInfo.segments.length === 0) {
        console.warn('Could not parse HLS segments, attempting direct download...');
        downloadDirectVideo(item, btnElement);
        return;
      }

      // If separate audio rendition is defined in master playlist, parse and fetch audio playlist
      let audioMediaInfo = null;
      if (separateAudioUri) {
        let aText = '';
        try {
          const aResp = await fetch(separateAudioUri);
          if (aResp.ok) aText = await aResp.text();
        } catch (e) {}

        if (!aText && activeTabId && !isInternalPage) {
          const aFetch = await new Promise(resolve => {
            sendTabMessageSafe(activeTabId, { type: 'PAGE_PROXY_FETCH', url: separateAudioUri }, resolve);
          });
          if (aFetch && aFetch.success) aText = aFetch.text;
        }

        if (aText && window.HlsParser) {
          audioMediaInfo = HlsParser.parseMedia(aText, separateAudioUri);
        }
      }

      // Download fMP4 init segment if available
      let initBuffer = null;
      if (mediaInfo.initSegmentUri) {
        initBuffer = await fetchSegmentBuffer(mediaInfo.initSegmentUri, activeTabId);
      }

      // Download AES-128 key if encrypted
      let keyBuffer = null;
      if (mediaInfo.keyInfo && mediaInfo.keyInfo.keyUri) {
        keyBuffer = await fetchSegmentBuffer(mediaInfo.keyInfo.keyUri, activeTabId);
      }

      const segments = mediaInfo.segments;
      const totalCount = segments.length;
      const chunkBuffers = new Array(totalCount).fill(null);
      let completed = 0;

      const concurrency = Math.min(4, totalCount);
      let nextIndex = 0;

      async function worker() {
        while (nextIndex < totalCount && !ctrl.isCancelled) {
          while (ctrl.isPaused && !ctrl.isCancelled) {
            await new Promise(r => setTimeout(r, 200));
          }
          if (ctrl.isCancelled || nextIndex >= totalCount) break;

          const idx = nextIndex++;
          const seg = segments[idx];

          let buf = null;
          let attempts = 0;

          while (attempts < 4 && !buf && !ctrl.isCancelled) {
            while (ctrl.isPaused && !ctrl.isCancelled) {
              await new Promise(r => setTimeout(r, 200));
            }
            if (ctrl.isCancelled) break;

            attempts++;
            try {
              buf = await fetchSegmentBuffer(seg.uri, activeTabId);
              if (buf && buf.byteLength > 0) {
                // Decrypt AES-128 chunk if encrypted
                if (keyBuffer && window.HlsParser && mediaInfo.keyInfo) {
                  let ivBuf;
                  if (mediaInfo.keyInfo.ivHex) {
                    const hex = mediaInfo.keyInfo.ivHex.replace(/^0x/i, '');
                    const match = hex.match(/.{1,2}/g) || [];
                    ivBuf = new Uint8Array(match.map(byte => parseInt(byte, 16)));
                  } else {
                    ivBuf = new Uint8Array(16);
                    new DataView(ivBuf.buffer).setUint32(12, idx);
                  }
                  buf = await HlsParser.decryptChunk(buf, keyBuffer, ivBuf);
                }

                chunkBuffers[idx] = buf;
                completed++;
                const pct = Math.round((completed / totalCount) * 100);
                ctrl.currentPercent = pct;
                ctrl.lastStatusText = `Downloading ${pct}% (${completed}/${totalCount})`;
                if (!ctrl.isPaused) {
                  updateDownloadProgress(btnElement, pct, ctrl.lastStatusText, 'downloading');
                }
                break;
              }
            } catch (e) {
              console.warn(`Segment ${idx} error:`, e);
            }
            if (!buf && attempts < 4 && !ctrl.isCancelled) {
              await new Promise(r => setTimeout(r, 250 * attempts));
            }
          }
        }
      }

      const workers = [];
      for (let i = 0; i < concurrency; i++) workers.push(worker());
      await Promise.all(workers);

      // Rescue pass: retry any segments that missed download to guarantee 100% contiguous stream!
      const missingCount = chunkBuffers.filter(c => !c).length;
      if (missingCount > 0) {
        ctrl.lastStatusText = `Rescuing ${missingCount} segments...`;
        if (!ctrl.isPaused) {
          updateDownloadProgress(btnElement, 98, ctrl.lastStatusText, 'downloading');
        }
        for (let i = 0; i < totalCount; i++) {
          while (ctrl.isPaused && !ctrl.isCancelled) {
            await new Promise(r => setTimeout(r, 200));
          }
          if (ctrl.isCancelled) break;

          if (!chunkBuffers[i]) {
            try {
              let rBuf = await fetchSegmentBuffer(segments[i].uri, activeTabId);
              if (rBuf && rBuf.byteLength > 0) {
                if (keyBuffer && window.HlsParser && mediaInfo.keyInfo) {
                  let ivBuf;
                  if (mediaInfo.keyInfo.ivHex) {
                    const hex = mediaInfo.keyInfo.ivHex.replace(/^0x/i, '');
                    const match = hex.match(/.{1,2}/g) || [];
                    ivBuf = new Uint8Array(match.map(byte => parseInt(byte, 16)));
                  } else {
                    ivBuf = new Uint8Array(16);
                    new DataView(ivBuf.buffer).setUint32(12, i);
                  }
                  rBuf = await HlsParser.decryptChunk(rBuf, keyBuffer, ivBuf);
                }
                chunkBuffers[i] = rBuf;
                completed++;
              }
            } catch (e) {}
            await new Promise(r => setTimeout(r, 150));
          }
        }
      }

      // Fetch separate audio segments if present in stream
      const audioChunkBuffers = [];
      if (audioMediaInfo && audioMediaInfo.segments.length > 0) {
        ctrl.lastStatusText = 'Downloading audio...';
        if (!ctrl.isPaused) {
          updateDownloadProgress(btnElement, 98, ctrl.lastStatusText, 'downloading');
        }
        const aSegs = audioMediaInfo.segments;
        const aBuffers = new Array(aSegs.length).fill(null);
        let aNext = 0;
        async function audioWorker() {
          while (aNext < aSegs.length && !ctrl.isCancelled) {
            while (ctrl.isPaused && !ctrl.isCancelled) {
              await new Promise(r => setTimeout(r, 200));
            }
            if (ctrl.isCancelled || aNext >= aSegs.length) break;

            const aIdx = aNext++;
            const aSeg = aSegs[aIdx];
            try {
              const aBuf = await fetchSegmentBuffer(aSeg.uri, activeTabId);
              if (aBuf) aBuffers[aIdx] = aBuf;
            } catch (e) {}
          }
        }
        const aWorkers = [];
        for (let i = 0; i < 4; i++) aWorkers.push(audioWorker());
        await Promise.all(aWorkers);
        audioChunkBuffers.push(...aBuffers.filter(Boolean));
      }

      const validChunks = chunkBuffers.filter(Boolean);
      if (validChunks.length === 0) {
        throw new Error('No video segments could be downloaded. Try Preview -> Record.');
      }

      updateDownloadProgress(btnElement, 99, 'Saving Video (MP4)...', 'downloading');

      // Assemble into 100% genuine MP4 container with proper seek index!
      // Output filename is strictly .mp4 - never .ts (eliminates unknown extension error)!
      const finalFilename = `${cleanTitle}.mp4`;
      let finalBlob = null;

      if (mediaInfo.isFmp4) {
        // Fragmented MP4 stream: prepend init segment and join media fragments
        const allParts = [];
        if (initBuffer) allParts.push(initBuffer);
        allParts.push(...validChunks);
        if (audioChunkBuffers.length > 0) allParts.push(...audioChunkBuffers);
        finalBlob = new Blob(allParts, { type: 'video/mp4' });
      } else {
        // MPEG-TS stream: transmux to proper fMP4 container with seek index
        // This enables instant seeking in VLC/MPC-HC/PotPlayer instead of 2-sec delay
        updateDownloadProgress(btnElement, 0, 'Optimizing MP4...', 'optimizing');
        finalBlob = await transmuxTsToMp4(validChunks, (prog) => {
          const optPct = Math.round(prog * 100);
          updateDownloadProgress(btnElement, optPct, `Optimizing: ${optPct}%`, 'optimizing');
        });
      }

      const objectUrl = URL.createObjectURL(finalBlob);

      // Trigger SINGLE download with EXACT video title!
      saveSingleFile(objectUrl, finalFilename);

      showToast(`✓ Downloaded: ${finalFilename}`);
      updateDownloadProgress(btnElement, 100, '✓ Saved!', 'completed');
    } catch (err) {
      console.error(err);
      showToast('Download error: ' + err.message);
      updateDownloadProgress(btnElement, 0, 'Download Video', 'reset');
    } finally {
      activeDownloads.delete(ctrlId);
    }
  }

  // -------------------------------------------------------------
  // 3. DIRECT FILE DOWNLOAD (With Exact Video Title)
  // -------------------------------------------------------------
  function downloadDirectVideo(item, btnElement) {
    if (!btnElement && item && item.id) {
      btnElement = document.querySelector(`.btn-download[data-id="${item.id}"]`);
    }
    const ctrlId = item.id || item.url;

    if (activeDownloads.has(ctrlId)) {
      togglePauseDownload(ctrlId);
      return;
    }

    const cleanTitle = sanitizeFilename(item.title || activeTabTitle || 'Video');
    const isAudio = item.category === 'audio';
    const ext = isAudio ? 'mp3' : 'mp4';
    const finalFilename = `${cleanTitle}.${ext}`;

    showToast(`Downloading: ${finalFilename}...`);
    updateDownloadProgress(btnElement, 35, 'Downloading...', 'downloading');

    sendRuntimeMessageSafe({
      type: 'TRIGGER_DOWNLOAD',
      url: item.url,
      filename: cleanTitle,
      category: item.category
    }, (res) => {
      if (res && res.success) {
        showToast(`✓ Download started: ${finalFilename}`);
        const downloadId = res.downloadId;

        if (downloadId && chrome.downloads) {
          const ctrl = {
            id: ctrlId,
            isPaused: false,
            btnElement,
            pause() {
              this.isPaused = true;
              chrome.downloads.pause(downloadId, () => {
                updateDownloadProgress(this.btnElement, 50, '⏸ Paused', 'paused');
                showToast('Download paused');
              });
            },
            resume() {
              this.isPaused = false;
              chrome.downloads.resume(downloadId, () => {
                updateDownloadProgress(this.btnElement, 50, 'Downloading...', 'downloading');
                showToast('Resuming download...');
              });
            }
          };

          activeDownloads.set(ctrlId, ctrl);
        } else {
          updateDownloadProgress(btnElement, 100, '✓ Saved!', 'completed');
        }
      } else {
        // Fallback to authenticated page fetch
        showToast('Saving video via page context...');
        updateDownloadProgress(btnElement, 60, 'Saving...', 'downloading');
        sendTabMessageSafe(activeTabId, {
          type: 'PAGE_FETCH_DOWNLOAD',
          url: item.url,
          filename: cleanTitle
        }, (pageRes) => {
          if (pageRes && pageRes.success) {
            showToast(`✓ Downloaded: ${finalFilename}`);
            updateDownloadProgress(btnElement, 100, '✓ Saved!', 'completed');
          } else {
            showToast('Download failed: ' + (pageRes?.error || 'Network error'));
            updateDownloadProgress(btnElement, 0, 'Download Video', 'reset');
          }
          activeDownloads.delete(ctrlId);
        });
      }
    });
  }

  // Single-File Save Helper: Ensures ONLY ONE file is EVER downloaded!
  function saveSingleFile(objectUrl, filename) {
    const cleanName = sanitizeFilename(filename.replace(/\.mp4$/i, '')) + '.mp4';

    // Register with background onDeterminingFilename listener to prevent Chrome from naming blob as UUID
    sendRuntimeMessageSafe({
      type: 'REGISTER_BLOB_DOWNLOAD',
      url: objectUrl,
      filename: cleanName
    });

    if (chrome.downloads) {
      chrome.downloads.download({
        url: objectUrl,
        filename: cleanName,
        saveAs: false
      }, (downloadId) => {
        if (chrome.runtime.lastError) {
          // Fallback to anchor click only if chrome.downloads failed!
          saveViaAnchor(objectUrl, cleanName);
        } else {
          setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);
        }
      });
    } else {
      saveViaAnchor(objectUrl, cleanName);
    }
  }

  function saveViaAnchor(objectUrl, filename) {
    const a = document.createElement('a');
    a.href = objectUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) document.body.removeChild(a);
      URL.revokeObjectURL(objectUrl);
    }, 1000);
  }

  // -------------------------------------------------------------
  // 4. CAPTURE PLAYING VIDEO (For Blob/MSE Players)
  // -------------------------------------------------------------
  function captureLivePlayer(item, btnElement) {
    if (!activeTabId || isInternalPage) return;
    const labelSpan = btnElement.querySelector('.btn-label');
    const cleanTitle = sanitizeFilename(item.title || 'Video');

    labelSpan.textContent = 'Capturing...';
    btnElement.classList.add('downloading');
    showToast(`Capturing video: ${cleanTitle}... Click again to finish.`);

    btnElement.onclick = () => {
      sendTabMessageSafe(activeTabId, { type: 'STOP_VIDEO_CAPTURE' }, () => {
        labelSpan.textContent = '✓ Saved Video';
        btnElement.classList.remove('downloading');
        btnElement.classList.add('completed');
        showToast(`✓ Saved: ${cleanTitle}.mp4`);
      });
    };

    sendTabMessageSafe(activeTabId, {
      type: 'START_VIDEO_CAPTURE',
      filename: cleanTitle
    });
  }

  // -------------------------------------------------------------
  // 5. FORCE VIDEO SCAN (Deep DOM Probe with Accurate Titles)
  // -------------------------------------------------------------
  function forceScanVideos() {
    if (!activeTabId) return;
    showToast('Scanning page for videos and titles...');

    chrome.scripting.executeScript({
      target: { tabId: activeTabId, allFrames: true },
      func: () => {
        const found = [];

        function cleanTitle(str) {
          if (!str) return 'Video';
          let s = str.trim().replace(/\s*[-|–—•]\s*(YouTube|Vimeo|Dailymotion|Twitter|X|Facebook|TikTok|Twitch|Watch Online|Free Full|HD).*$/i, '');
          s = s.replace(/[<>:"/\\|?*\x00-\x1F\r\n\t]/g, '_').trim();
          s = s.replace(/_+/g, '_').replace(/\.+$/, '');
          return s.slice(0, 100) || 'Video';
        }

        const pageTitle = cleanTitle(
          document.querySelector('meta[property="og:title"]')?.getAttribute('content') ||
          document.querySelector('h1')?.innerText ||
          document.title
        );

        function scan(root) {
          const vids = root.querySelectorAll('video');
          vids.forEach(v => {
            const s = v.currentSrc || v.src;
            if (s) {
              const elTitle = v.getAttribute('title') || v.getAttribute('aria-label');
              found.push({
                url: s,
                title: elTitle ? cleanTitle(elTitle) : pageTitle,
                resolution: v.videoWidth ? `${v.videoWidth}x${v.videoHeight}` : null,
                isBlob: s.startsWith('blob:')
              });
            }
          });
          const all = root.querySelectorAll('*');
          all.forEach(el => {
            if (el.shadowRoot) scan(el.shadowRoot);
          });
        }
        scan(document);
        return found;
      }
    }, (results) => {
      let count = 0;
      if (results && results.length > 0) {
        results.forEach(f => {
          if (f.result && Array.isArray(f.result)) {
            f.result.forEach(m => {
              sendRuntimeMessageSafe({
                type: 'MEDIA_DETECTED',
                media: {
                  url: m.url,
                  title: m.title || 'Video',
                  format: m.resolution ? `${m.resolution} MP4` : 'MP4 VIDEO',
                  category: 'video',
                  resolution: m.resolution,
                  isBlobPlayer: m.isBlob
                }
              });
              count++;
            });
          }
        });
        setTimeout(loadMedia, 300);
        showToast(`Found ${count} video(s)!`);
      } else {
        showToast('No active video elements found on this page.');
      }
    });
  }

  btnForceDownload.addEventListener('click', forceScanVideos);
  btnForceEmpty.addEventListener('click', forceScanVideos);

  // Batch Download
  btnDownloadAll.addEventListener('click', async () => {
    const list = allMedia.filter(m => m.category === 'video');
    showToast(`Downloading all ${list.length} videos...`);
    for (const item of list) {
      const cardBtn = document.querySelector(`.btn-download[data-id="${item.id}"]`);
      if (isHlsMedia(item)) {
        await downloadHlsVideoInPopup(item, cardBtn);
      } else {
        downloadDirectVideo(item, cardBtn);
      }
      await new Promise(r => setTimeout(r, 800));
    }
  });

  // Filter Tabs
  const tabButtons = document.querySelectorAll('.tab-btn');
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tabButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.getAttribute('data-filter');
      renderMedia();
    });
  });

  // Search
  searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value.trim();
    renderMedia();
  });

  // Rescan
  btnRescan.addEventListener('click', () => {
    showToast('Rescanning...');
    if (!isInternalPage && activeTabId) {
      sendTabMessageSafe(activeTabId, { type: 'SCAN_PAGE_NOW' }, () => {
        setTimeout(loadMedia, 300);
      });
    } else {
      setTimeout(loadMedia, 300);
    }
  });

  // Clear
  btnClearMedia.addEventListener('click', () => {
    sendRuntimeMessageSafe({ type: 'CLEAR_TAB_MEDIA' }, () => {
      allMedia = [];
      updateCounts();
      renderMedia();
      showToast('Queue cleared');
    });
  });

  // Options
  btnOptions.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&#039;');
  }

  if (chrome.downloads && chrome.downloads.onChanged) {
    chrome.downloads.onChanged.addListener((delta) => {
      if (delta.state && (delta.state.current === 'complete' || delta.state.current === 'interrupted')) {
        for (const [id, ctrl] of activeDownloads.entries()) {
          if (ctrl.btnElement && delta.state.current === 'complete') {
            updateDownloadProgress(ctrl.btnElement, 100, '✓ Saved!', 'completed');
          }
          activeDownloads.delete(id);
        }
      }
    });
  }

  // Initial load
  loadMedia();
});
